from django.apps import AppConfig


class ClockAppConfig(AppConfig):
    name = 'clock_app'
