from django.apps import AppConfig


class AppLevelConfig(AppConfig):
    name = 'app_level'
